# PillPortal
A website that is used by doctors to dispense drugs virtually after verifying prescriptions, which will then be delivered to the patients via a delivery person.
It also acts as a database for medicine where users can look up descriptions of drugs.
It also has a reminder for your dosage.
